// WT_DSML/database.js

const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Sid_j@21',
    database: 'miniproject'
});

db.connect((err) => {
    if (err) throw err;
    console.log("Connected to database");
});

module.exports = {db};
