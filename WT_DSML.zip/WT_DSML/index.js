// WT_DSML/index.js

const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const { generateUniqueID } = require('./server.js');
// const db = require('./database');  // Import the database connection
const { generateFile } = require('C://Users//ADMIN//Documents//WEB DEVELOPMENT//online compiler//backend//generateFiles.js');
const { executeCpp } = require('C://Users//ADMIN//Documents//WEB DEVELOPMENT//online compiler//backend//executeCpp.js');
const mysql = require('mysql2');
const { Console, log } = require('console');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Sid_j@21',
    database: 'miniproject'
});

db.connect((err) => {
    if (err) throw err;
    console.log("Connected to database");
});


const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/style5.css', express.static(path.join(__dirname, '..', 'online compiler', 'backend', 'views', 'style5.css')));
app.use('/script4.js', express.static(path.join(__dirname, '..', 'online compiler', 'backend', 'views', 'script4.js')));


// Serve static files
// app.use(express.static(path.join(__dirname, 'public')));

// Session middleware
app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));

// // Use the WT_DSML route// app.use('/wt_dsml', wt_dsml_routes);  // Use the app
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, 'views')));


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Serve CSS and JS files
app.get('/WT_DSML/views/style.css', (req, res) => {
        res.setHeader('Content-Type', 'text/css');
        res.sendFile(path.join(__dirname, 'views', 'style.css'));
    });

app.get('/WT_DSML/views/script.js', (req, res) => {
    res.setHeader('Content-Type', 'text/javascript');
    res.sendFile(path.join(__dirname, 'views', 'script.js'));
});

app.get('/WT_DSML/views/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/WT_DSML/views/style2.css', (req, res) => {
    res.setHeader('Content-Type', 'text/css');
    res.sendFile(path.join(__dirname, 'views', 'style2.css'));
});

app.get('/WT_DSML/views/style3.css', (req, res) => {
    res.setHeader('Content-Type', 'text/css');
    res.sendFile(path.join(__dirname, 'views', 'style3.css'));
});

app.get('/WT_DSML/views/script2.js', (req, res) => {
    res.setHeader('Content-Type', 'text/javascript');
    res.sendFile(path.join(__dirname, 'views', 'script2.js'));
});

app.get('/WT_DSML/views/script3.js', (req, res) => {
    res.setHeader('Content-Type', 'text/javascript');
    res.sendFile(path.join(__dirname, 'views', 'script3.js'));
});

app.get('/WT_DSML/views/signup.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'signup.html'));
});
app.get("/WT_DSML/views/logo1.png",(req,res)=>{
    res.sendFile(path.join(__dirname, 'views', 'logo1.png'));
})

app.post('/WT_DSML/views/signup.html', (req, res) => {
    let email = req.body.email;
    let password = req.body.password;
    let confirmPassword = req.body.confirmPassword;

    let userID = generateUniqueID();

    db.query('INSERT INTO user (userID, email, password) VALUES (?, ?, ?)', [userID, email, password], (err, result) => {
        if (err) {
            console.error('Error inserting user:', err);
            return res.status(500).send('Failed to register user');
        }

        console.log('User registered successfully');
        res.redirect('/wt_dsml/views/login.html');
    });
});

app.post('/WT_DSML/views/login.html', (req, res) => {
    let mail = req.body.email;
    let pass = req.body.password;
    db.query("SELECT * FROM user WHERE email = ? AND password = ?", [mail, pass], (err, result, fields) => {
        if (err) {
            console.error('Error retrieving user:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (result.length > 0) {
            req.session.user = { email: mail }; // Store user email in session
            res.redirect(302, `/wt_dsml/profile`);
            console.log("Login successful");
        } else {
            res.redirect(302, '/wt_dsml/login'); // Redirect back to the login page
            console.log("Login failed");
        }
    });
});

app.get('/WT_DSML/profile', (req, res) => {
    if (!req.session || !req.session.user || !req.session.user.email) {
        // Redirect to login if user is not authenticated
        return res.redirect('/wt_dsml/login');
    }
    
    const email = req.session.user.email;
    res.render('profile1', { email });
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
        }
        res.redirect('/wt_dsml/login');
    });
});

app.get('/WT_DSML/questions/:testID', async (req, res) => {
    const testID = req.params.testID;

    try {
        // Fetch questions based on the testID from the database
        const [questions] = await db.promise().query("SELECT * FROM questions WHERE testID = ?", [testID]);
        
        if (questions.length > 0) {
            console.log(questions);
        }

        // Render the testQuestion.ejs view with the fetched questions
        res.render('testQuestion', { testID, questions });

    } catch (error) {
        console.error("Error fetching questions:", error);
        res.status(500).send("An error occurred while fetching questions.");
    }
});

// Add this route to handle code.ejs
app.post('/opencode', (req, res) => {
    const { testID, questionID } = req.body;
    console.log('Fetching question for questionID:', questionID);

    // Fetch question details based on questionID from the database
    db.query("SELECT * FROM questions WHERE questionID = ?", [questionID], async (err, result) => {
        if (err) {
            console.error('Error retrieving question:', err.message);
            return res.status(500).send('Internal Server Error');
        }

        if (result.length === 0) {
            console.error('Question not found');
            return res.status(404).send('Question not found');
        }

        const question = result[0];
        console.log('Fetched question:', question);
        res.render(path.join(__dirname, '..', 'online compiler', 'backend', 'views', 'code.ejs'), { question, testID });
    });
});



app.post("/run", async (req, res) => {
    const { language = "cpp", code, questionID } = req.body;
  
    if (!code) {
        return res.status(400).json({ success: false, error: "Empty code body" });
    }
  
    try {
        const filepath = await generateFile(language, code);
        const output = await executeCpp(filepath);
        console.log(output);
        // Fetch test cases for the given questionID
        const [testCases] = await db.promise().query("SELECT * FROM testCases WHERE questionID = ?", [questionID]);

        let isPassed = true;

        // Compare the program's output with test cases
        for (const testCase of testCases) {
            if (output.trim() !== testCase.stdoutput.trim()) {
                isPassed = false;
                break;
            }
        }

        // Prepare the response based on the comparison result
        const response = {
            output,
            isPassed,
            error: null
        };

        return res.json(response);
    } catch (error) {
        console.error("Error executing C++ code:", error);
        
        // Update the response to include the error message
        return res.status(500).json({ success: false, error: error.message });
    }
});

app.post('/join-test', (req, res) => {
    const testID = req.body.testID; 

    // Check if test with the given testID exists
    db.query("SELECT * FROM Test WHERE testID = ?", [testID], (err, result) => {
        if (err) {
            console.error('Error checking test:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (result.length === 0) {
            // Test does not exist
            console.log('Test does not exist');
            return res.status(404).send('Test does not exist');
        }

        // Test exists, redirect to testQuestion.ejs
        res.redirect(`/WT_DSML/questions/${testID}`);
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});


// const express = require('express');
// const mysql = require('mysql2');
// const bodyParser = require('body-parser');
// const path = require('path');
// const session = require('express-session');
// const { generateUniqueID } = require('./server.js');
// const { db } = require('../online compiler/backend/index.js');


// const app = express();
// const port = 3000;

// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());
// // Serve CSS and JS files
// app.use('/style5.css', express.static(path.join(__dirname, '..', 'online compiler', 'backend', 'views', 'style5.css')));
// app.use('/script4.js', express.static(path.join(__dirname, '..', 'online compiler', 'backend', 'views', 'script4.js')));

// // Initialize session middleware
// app.use(session({
//     secret: 'secret', // Change this to a long random string for production
//     resave: true,
//     saveUninitialized: true
// }));

// const connection = mysql.createConnection({
//     host: 'localhost',
//     user: 'root',
//     database: 'miniproject',
//     password: 'Sid_j@21'
// });

// connection.connect((err) => {
//     if (err) throw err;
//     console.log("Connected to database");
// });

// app.set("view engine", "ejs");
// app.set("views", path.join(__dirname, "views"));
// app.use(express.static(path.join(__dirname, 'views')));

// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'index.html'));
// });

// // Serve CSS and JS files
// // Add similar routes for other static files if needed
// app.get('/WT_DSML/views/style.css', (req, res) => {
//     res.setHeader('Content-Type', 'text/css');
//     res.sendFile(path.join(__dirname, 'views', 'style.css'));
// });

// app.get('/WT_DSML/views/script.js', (req, res) => {
//     res.setHeader('Content-Type', 'text/javascript');
//     res.sendFile(path.join(__dirname, 'views', 'script.js'));
// });

// app.get('/WT_DSML/views/login.html', (req, res) => {
//     res.sendFile(path.join(__dirname, 'views', 'login.html'));
// });

// app.get('/WT_DSML/views/style2.css', (req, res) => {
//     res.setHeader('Content-Type', 'text/css');
//     res.sendFile(path.join(__dirname, 'views', 'style2.css'));
// });

// app.get('/WT_DSML/views/style3.css', (req, res) => {
//     res.setHeader('Content-Type', 'text/css');
//     res.sendFile(path.join(__dirname, 'views', 'style3.css'));
// });

// app.get('/WT_DSML/views/script2.js', (req, res) => {
//     res.setHeader('Content-Type', 'text/javascript');
//     res.sendFile(path.join(__dirname, 'views', 'script2.js'));
// });

// app.get('/WT_DSML/views/script3.js', (req, res) => {
//     res.setHeader('Content-Type', 'text/javascript');
//     res.sendFile(path.join(__dirname, 'views', 'script3.js'));
// });

// app.get('/WT_DSML/views/signup.html', (req, res) => {
//     res.sendFile(path.join(__dirname, 'views', 'signup.html'));
// });

// app.post('/WT_DSML/views/signup.html', (req, res) => {
//     let email = req.body.email;
//     let password = req.body.password;
//     let confirmPassword = req.body.confirmPassword;

//     let userID = generateUniqueID();

//     connection.query('INSERT INTO user (userID, email, password) VALUES (?, ?, ?)', [userID, email, password], (err, result) => {
//         if (err) {
//             console.error('Error inserting user:', err);
//             return res.status(500).send('Failed to register user');
//         }

//         console.log('User registered successfully');
//         res.redirect('/WT_DSML/views/login.html');
//     });
// });

// app.post('/WT_DSML/views/login.html', (req, res) => {
//     let mail = req.body.email;
//     let pass = req.body.password;
//     connection.query("SELECT * FROM user WHERE email = ? AND password = ?", [mail, pass], (err, result, fields) => {
//         if (err) {
//             console.error('Error retrieving user:', err);
//             return res.status(500).send('Internal Server Error');
//         }

//         if (result.length > 0) {
//             req.session.user = { email: mail }; // Store user email in session
//             res.redirect(302, `/profile`);
//             console.log("Login successful");
//         } else {
//             res.redirect(302, '/login'); // Redirect back to the login page
//             console.log("Login failed");
//         }
//     });
// });

// // Profile page route with authentication middleware
// app.get('/profile', (req, res) => {
//     if (!req.session || !req.session.user || !req.session.user.email) {
//         // Redirect to login if user is not authenticated
//         return res.redirect('/login');
//     }
    
//     const email = req.session.user.email;
//     res.render('profile1', { email });
// });
// app.get('/login', (req, res) => {
//     res.sendFile(path.join(__dirname, 'views', 'login.html'));
// });
// // Logout route
// app.get('/logout', (req, res) => {
//     req.session.destroy((err) => {
//         if (err) {
//             console.error('Error destroying session:', err);
//         }
//         res.redirect('/login');
//     });
// });

// // Add this new route to the WT_DSML/index.js file
// // Add this new route to the WT_DSML/index.js file

// // Fetch questions from the database and render the testQuestion.ejs template
// // Fetch questions from the database and render the testQuestion.ejs template
// app.get('/questions/:testID', async (req, res) => {
//     const testID = req.params.testID;

//     try {
//         // Fetch questions based on the testID from the database
//         const [questions] = await db.promise().query("SELECT * FROM questions WHERE testID = ?", [testID]);
        
//         if (questions.length > 0) {
//             console.log(questions);  // Log the fetched questions
//             // console.log(questions[0]);  // Log the first question
//         }

//         // Render the testQuestion.ejs view with the fetched questions
//         res.render('testQuestion', { testID, questions });

//     } catch (error) {
//         console.error("Error fetching questions:", error);
//         res.status(500).send("An error occurred while fetching questions.");
//     }
// });


// // Route to open the code.ejs template with the selected question details
// app.post('/openCode', async (req, res) => {
//     const { questionID } = req.body;

//     try {
//         // Fetch the question details based on the questionID from the database
//         const [question] = await db.promise().query("SELECT * FROM questions WHERE questionID = ?", [questionID]);

//         if (question.length === 0) {
//             return res.status(404).json({ success: false, error: "Question not found" });
//         }

//         // Render the code.ejs view with the fetched question details
//         res.render(path.join(__dirname, '..', 'online compiler', 'backend', 'views', 'code'), { question: question[0] });

//     } catch (error) {
//         console.error("Error fetching question details:", error);
//         res.status(500).send("An error occurred while fetching question details.");
//     }
// });

// app.post('/join-test', (req, res) => {
//     const testID = req.body.testID; // Assuming the test ID is sent in the request body

//     // Here you can redirect the user to the questions page for the given test ID
//     res.redirect(`/questions/${testID}`);
// });


// app.listen(port, () => {
//     console.log(`Server running at http://localhost:${port}`);
// });


