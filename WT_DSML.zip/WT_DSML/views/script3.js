let a = document.querySelector("#join_t");
let b = document.querySelector("#prof");
let c = document.querySelector("#conduct_t");
let d = document.querySelector("#hist");
let sec1 = document.querySelector("#content_details");
let sec2 = document.querySelector("#JT");
let sec3 = document.querySelector("#CT");
let sec4 = document.querySelector("#HT");
sec2.style.display = "none";
    sec3.style.display = "none";
    sec4.style.display = "none";
a.addEventListener("click",()=>{
    // console.log(e);
    a.classList.add("active");
    // console.dir(sec1);
    sec2.style.display = "";
    sec1.style.display = "none";
    sec3.style.display = "none";
    sec4.style.display = "none";
    b.classList.remove("active");
    c.classList.remove("active");
    d.classList.remove("active");

});
b.addEventListener("click",()=>{
    // console.log(e);
    b.classList.add("active");
    // console.dir(sec1);
    sec1.style.display = "";
    sec2.style.display = "none";
    sec3.style.display = "none";
    sec4.style.display = "none";
    a.classList.remove("active");
    c.classList.remove("active");
    d.classList.remove("active");

});
c.addEventListener("click",()=>{
    // console.log(e);
    c.classList.add("active");
    // console.dir(sec1);
    sec2.style.display = "none";
    sec1.style.display = "none";
    sec3.style.display = "";
    sec4.style.display = "none";
    a.classList.remove("active");
    b.classList.remove("active");
    d.classList.remove("active");

});
d.addEventListener("click",()=>{
    // console.log(e);
    d.classList.add("active");
    // console.dir(sec1);
    sec2.style.display = "none";
    sec1.style.display = "none";
    sec3.style.display = "none";
    sec4.style.display = "";
    a.classList.remove("active");
    b.classList.remove("active");
    c.classList.remove("active");

});