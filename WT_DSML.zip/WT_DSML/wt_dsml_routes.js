// WT_DSML/wt_dsml_routes.js

const express = require('express');
const path = require('path');
const db = require('./database');
const { generateUniqueID } = require('./server.js');

const router = express.Router();

router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Serve CSS and JS files
router.get('/views/style.css', (req, res) => {
    res.setHeader('Content-Type', 'text/css');
    res.sendFile(path.join(__dirname, 'views', 'style.css'));
});

router.get('/views/script.js', (req, res) => {
    res.setHeader('Content-Type', 'text/javascript');
    res.sendFile(path.join(__dirname, 'views', 'script.js'));
});

router.get('/views/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

router.get('/views/style2.css', (req, res) => {
    res.setHeader('Content-Type', 'text/css');
    res.sendFile(path.join(__dirname, 'views', 'style2.css'));
});

router.get('/views/style3.css', (req, res) => {
    res.setHeader('Content-Type', 'text/css');
    res.sendFile(path.join(__dirname, 'views', 'style3.css'));
});

router.get('/views/script2.js', (req, res) => {
    res.setHeader('Content-Type', 'text/javascript');
    res.sendFile(path.join(__dirname, 'views', 'script2.js'));
});

router.get('/views/script3.js', (req, res) => {
    res.setHeader('Content-Type', 'text/javascript');
    res.sendFile(path.join(__dirname, 'views', 'script3.js'));
});

router.get('/views/signup.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'signup.html'));
});

router.post('/views/signup.html', (req, res) => {
    let email = req.body.email;
    let password = req.body.password;
    let confirmPassword = req.body.confirmPassword;

    let userID = generateUniqueID();

    db.query('INSERT INTO user (userID, email, password) VALUES (?, ?, ?)', [userID, email, password], (err, result) => {
        if (err) {
            console.error('Error inserting user:', err);
            return res.status(500).send('Failed to register user');
        }

        console.log('User registered successfully');
        res.redirect('/wt_dsml/views/login.html');
    });
});

router.post('/views/login.html', (req, res) => {
    let mail = req.body.email;
    let pass = req.body.password;
    db.query("SELECT * FROM user WHERE email = ? AND password = ?", [mail, pass], (err, result, fields) => {
        if (err) {
            console.error('Error retrieving user:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (result.length > 0) {
            req.session.user = { email: mail }; // Store user email in session
            res.redirect(302, `/wt_dsml/profile`);
            console.log("Login successful");
        } else {
            res.redirect(302, '/wt_dsml/login'); // Redirect back to the login page
            console.log("Login failed");
        }
    });
});

router.get('/profile', (req, res) => {
    if (!req.session || !req.session.user || !req.session.user.email) {
        // Redirect to login if user is not authenticated
        return res.redirect('/wt_dsml/login');
    }
    
    const email = req.session.user.email;
    res.render('profile1', { email });
});

router.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
        }
        res.redirect('/wt_dsml/login');
    });
});

router.get('/questions/:testID', async (req, res) => {
    const testID = req.params.testID;

    try {
        // Fetch questions based on the testID from the database
        const [questions] = await db.promise().query("SELECT * FROM questions WHERE testID = ?", [testID]);
        
        if (questions.length > 0) {
            console.log(questions);
        }

        // Render the testQuestion.ejs view with the fetched questions
        res.render('testQuestion', { testID, questions });

    } catch (error) {
        console.error("Error fetching questions:", error);
        res.status(500).send("An error occurred while fetching questions.");
    }
});

router.post('/openCode', async (req, res) => {
    const { questionID } = req.body;

    try {
        // Fetch the question details based on the questionID from the database
        const [question] = await db.promise().query("SELECT * FROM questions WHERE questionID = ?", [questionID]);

        if (question.length === 0) {
            return res.status(404).json({ success: false, error: "Question not found" });
        }

        // Render the code.ejs view with the fetched question details
        res.render(path.join(__dirname, '..', 'online compiler', 'backend', 'views', 'code'), { question: question[0] });

    } catch (error) {
        console.error("Error fetching question details:", error);
        res.status(500).send("An error occurred while fetching question details.");
    }
});

router.post('/join-test', (req, res) => {
    const testID = req.body.testID; 

    res.redirect(`/wt_dsml/questions/${testID}`);
});

module.exports = router;