function generateUniqueID() {
    // Generate 4 random numbers
    const numbers = Math.floor(1000 + Math.random() * 9000);

    // Generate a random alphabet character
    const alphabet = String.fromCharCode(65 + Math.floor(Math.random() * 26));

    // Concatenate the numbers and alphabet character
    const uniqueID = numbers.toString() + alphabet;

    return uniqueID;
}

module.exports=  {generateUniqueID};
