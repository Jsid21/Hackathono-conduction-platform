document.addEventListener('DOMContentLoaded', () => {
    const codeForm = document.getElementById('codeForm');
    const errorMsgDiv = document.querySelector('.errormsg'); // Select the error message div
    const testPassDiv = document.querySelector('.testpass'); // Select the test pass div
    const testFailDiv = document.querySelector('.testfail'); // Select the test fail div

    codeForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(codeForm);
        const code = formData.get('code');
        const language = formData.get('language');
        const questionID = formData.get('questionID'); // Include questionID in the request body

        try {
            const response = await fetch('/run', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ code, language, questionID }), // Include questionID in the request body
            });

            if (!response.ok) {
                throw new Error('Server response was not ok');
            }

            const data = await response.json();
            document.getElementById('output').innerText = data.output;

            // Toggle test pass/fail divs based on the value of isPassed in the response
            if (data.isPassed) {
                testPassDiv.style.display = 'block';
                testFailDiv.style.display = 'none';
                errorMsgDiv.style.display = 'none'; // Hide error message div
            } else {
                testPassDiv.style.display = 'none';
                testFailDiv.style.display = 'block';
                errorMsgDiv.style.display = 'none'; // Hide error message div
            }

        } catch (error) {
            console.error('Error executing code:', error);
            // Display error message
            errorMsgDiv.style.display = 'block';
            testPassDiv.style.display = 'none';
            testFailDiv.style.display = 'none';
        }
    });
});