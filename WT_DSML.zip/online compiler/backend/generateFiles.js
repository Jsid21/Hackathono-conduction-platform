const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid'); // Import uuidv4 from uuid package

const dirCodes = path.join(__dirname, "codes");

if (!fs.existsSync(dirCodes)) {
    fs.mkdirSync(dirCodes, { recursive: true });
}

const generateFile = async (format, content) => {
    const jobId = uuidv4(); // Generate unique identifier
    const filename = `${jobId}.${format}`; // Use backticks for string interpolation
    const filepath = path.join(dirCodes, filename);
    await fs.promises.writeFile(filepath, content); // Use fs.promises.writeFile instead of fs.writeFileSync
    return filepath;
};

module.exports = {
    generateFile,
};