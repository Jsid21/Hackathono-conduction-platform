#include <iostream>
int main() {
    std::cout << "HELLO " << std::endl;
    return 0;
}
