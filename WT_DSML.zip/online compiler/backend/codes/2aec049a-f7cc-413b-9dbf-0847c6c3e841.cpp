#include <iostream>
int main() {
    std::cout << "HELLO WORLD" << l;
    return 0;
}
