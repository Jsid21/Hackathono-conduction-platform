#include <iostream>
int main() {
    std::cout << "15" << std::endl;
    return 0;
}
