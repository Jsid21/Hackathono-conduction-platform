#include <iostream>
int main() {
    std::cout << "HELLO W" << std::endl;
    return 0;
}
