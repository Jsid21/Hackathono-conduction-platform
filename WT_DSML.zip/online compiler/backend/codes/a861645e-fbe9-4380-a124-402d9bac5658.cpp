#include <iostream>
int main() {
    std::cout << " WORLD" << std::endl;
    return 0;
}
