#include <iostream>
int main() {
    std::cout <<"5" << std::endl;
    return 0;
}
