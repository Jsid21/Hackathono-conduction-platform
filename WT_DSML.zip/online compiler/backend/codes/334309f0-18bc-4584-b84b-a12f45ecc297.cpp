#include <iostream>
int main() {
    std::cout << "HELLO WORLD" << std::endl;
    return 0
}
