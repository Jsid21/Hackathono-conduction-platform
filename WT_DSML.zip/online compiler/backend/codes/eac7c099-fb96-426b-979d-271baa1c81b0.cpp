#include <iostream>
int miiain() {
    std::cout << "HELLO WORLD" << std::endl;
    return 0;
}
