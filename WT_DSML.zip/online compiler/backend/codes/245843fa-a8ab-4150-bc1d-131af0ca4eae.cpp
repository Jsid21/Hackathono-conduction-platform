#include <iostream>
main() {
    std::cout << "HELLO WORLD" << std::endl;
}
