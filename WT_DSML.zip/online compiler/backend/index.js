const express = require("express");
const { generateFile } = require('./generateFiles');
const { executeCpp } = require("./executeCpp");

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.get('/', (req, res) => {
    return res.json({ hello: "world" });
});

app.post("/run", async (req, res) => {
  const { language = "cpp", code } = req.body;

  if (!code) {
      return res.status(400).json({ success: false, error: "Empty code body" });
  }

  try {
      const filepath = await generateFile(language, code);
      const output =  await executeCpp(filepath);
      console.log(output);
      return res.json({output });
  } catch (error) {
      console.error("Error executing C++ code:", error);
      return res.status(500).json({ success: false, error: "Error executing C++ code" });
  }
});

app.listen(5000, () => {
    console.log('Listening to port 5000');
});